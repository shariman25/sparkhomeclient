export class User {
    constructor(
        public first_name: string,
        public last_name: String,
        public email: string,
        public api_token: string) { }
  }