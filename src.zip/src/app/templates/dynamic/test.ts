/**
 * Created by tpadley on 2016-10-06.
 */

import {Component} from "@angular/core";

@Component({
	selector: "dv6-test",
	template: require("./.html")
})

export class TestComponent {
	constructor() {
	}
}
