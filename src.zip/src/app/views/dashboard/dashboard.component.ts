import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {AuthenticationService} from './../../auth/authentication.service';

@Component({
  templateUrl: 'dashboard.component.html'
})
export class DashboardComponent {

  constructor( ) { }

  

}
