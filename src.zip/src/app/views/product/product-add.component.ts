import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: 'product-add.component.html'
})
export class ProductAddComponent {

  constructor( ) { }

}
