import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  templateUrl: 'product-list.component.html'
})
export class ProductListComponent {

  constructor( ) { }

}
